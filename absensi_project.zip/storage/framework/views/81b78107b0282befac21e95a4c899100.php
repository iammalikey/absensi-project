<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
  <?php if(isset($title)): ?>
    <title inertia><?php echo e($title); ?> - <?php echo e(config('app.name', 'Laravel')); ?></title>
  <?php else: ?>
    <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>
  <?php endif; ?>
  <?php if(env('APP_ENV') == 'production'): ?>
    <meta name="robots" content="index, follow" />
  <?php else: ?>
    <meta name="robots" content="noindex, nofollow" />
  <?php endif; ?>
  <?php if(isset($description)): ?>
    <meta name="description" content="<?php echo e($description); ?>" />
  <?php endif; ?>
  <?php if(isset($tag)): ?>
    <meta name="tag" content="<?php echo e($tag); ?>" />
  <?php endif; ?>
  <?php if(isset($keywords)): ?>
    <meta name="keywords" content="<?php echo e($keywords); ?>" />
  <?php endif; ?>
  <?php if(isset($created_at)): ?>
    <meta name="date.created" content="<?php echo e($created_at); ?>" />
  <?php endif; ?>
  <?php if(isset($last_modified)): ?>
    <meta name="last-modified" content="<?php echo e($last_modified); ?>" />
  <?php endif; ?>
  <?php if(isset($environment)): ?>
    <meta name="environment" content="<?php echo e($environment); ?>" />
  <?php endif; ?>
  <?php if(isset($user_signed_in)): ?>
    <meta name="user-signed-in" content="<?php echo e($user_signed_in); ?>" />
  <?php endif; ?>
  <?php if(isset($og_type)): ?>
    <meta property="og:type" content="<?php echo e($og_type); ?>" />
  <?php endif; ?>
  <?php if(isset($og_url)): ?>
    <meta property="og:url" content="<?php echo e($og_url); ?>" />
  <?php endif; ?>
  <?php if(isset($og_title)): ?>
    <meta property="og:title" content="<?php echo e($og_title); ?>" />
  <?php endif; ?>
  <?php if(isset($og_description)): ?>
    <meta property="og:description" content="<?php echo e($og_description); ?>" />
  <?php endif; ?>
  <?php if(isset($og_site_name)): ?>
    <meta property="og:site_name" content="<?php echo e($og_site_name); ?>" />
  <?php endif; ?>
  <?php if(isset($og_image)): ?>
    <meta property="og:image" content="<?php echo e($og_image); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_site)): ?>
    <meta name="twitter:site" content="<?php echo e($twitter_site); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_creator)): ?>
    <meta name="twitter:creator" content="<?php echo e($twitter_creator); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_url)): ?>
    <meta name="twitter:url" content="<?php echo e($twitter_url); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_title)): ?>
    <meta name="twitter:title" content="<?php echo e($twitter_title); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_description)): ?>
    <meta name="twitter:description" content="<?php echo e($twitter_description); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_card)): ?>
    <meta name="twitter:card" content="<?php echo e($twitter_card); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_widgets_new_embed_design)): ?>
    <meta name="twitter:widgets:new-embed-design" content="<?php echo e($twitter_widgets_new_embed_design); ?>" />
  <?php endif; ?>
  <?php if(isset($twitter_image)): ?>
    <meta name="twitter:image" content="<?php echo e($twitter_image); ?>" />
  <?php endif; ?>
  <?php if(isset($apple_mobile_web_app_title)): ?>
    <meta name="apple-mobile-web-app-title" content="<?php echo e($apple_mobile_web_app_title); ?>" />
  <?php endif; ?>
  <?php if(isset($application_name)): ?>
    <meta name="application-name" content="<?php echo e($application_name); ?>" />
  <?php endif; ?>
  <?php if(isset($fb_pages)): ?>
    <meta property="fb:pages" content="<?php echo e($fb_pages); ?>" />
  <?php endif; ?>
  <?php if(isset($theme_color)): ?>
    <meta name="theme-color" content="<?php echo e($theme_color); ?>" />
  <?php endif; ?>
  
  <link rel="preconnect" href="https://fonts.bunny.net">
  <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
  <?php echo app('Tightenco\Ziggy\BladeRouteGenerator')->generate(); ?>
  <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx', "resources/js/Pages/{$page['component']}.jsx"]); ?>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>

  <link rel="manifest" href="/build/manifest.webmanifest">
</head>

<body class="font-sans antialiased">
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
  <script>
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then(() => {
        console.log('Service Worker Ready');
      });
    }
  </script>
</body>

</html>
<?php /**PATH C:\laragon\www\absensi_project\resources\views/app.blade.php ENDPATH**/ ?>