<table>
    <thead>
        <tr>
            <th>Employee</th>
            <th>Date</th>
            <th>Clock In</th>
            <th>Clock Out</th>
            
            <th>Radius (km)</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($attendance->user->name); ?></td>
            <td><?php echo e($attendance->date); ?></td>
            <td><?php echo e($attendance->clock_in); ?></td>
            <td><?php echo e($attendance->clock_out ?? '-'); ?></td>
            
            <td><?php echo e(number_format($attendance->distance, 2)); ?> km</td>
            <td><?php echo e($attendance->status); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\absensi_project\resources\views/exports/logs.blade.php ENDPATH**/ ?>