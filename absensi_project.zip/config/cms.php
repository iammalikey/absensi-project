<?php

// SETTING CMS CONCRETE URL
return [
  'path' => env("CMS_PATH", 'work-5p4c3s'),
  'enable' => env("CMS_ENABLE", false),
];
