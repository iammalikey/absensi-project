import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { Box, Select, MenuItem, TableContainer, Paper, Table, TableHead, TableRow, TableCell, TableBody } from "@mui/material";
import { router } from "@inertiajs/react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Detail({ log, selectedMonth }) {
  const [month, setMonth] = useState(selectedMonth || "");
  const availableMonths = ["2025-01", "2025-02", "2025-03"];
  const handleMonthChange = (event) => {
    setMonth(event.target.value);
    router.get(route("cms.log.show", { user: log.id, month: event.target.value }));
  };
  console.log(log.attendances);
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Attendance Detail", subtitle: `Details for ${log.name}` }),
    /* @__PURE__ */ jsx(Box, { className: "mb-4 flex items-center gap-2", children: /* @__PURE__ */ jsxs(Select, { value: month, onChange: handleMonthChange, displayEmpty: true, size: "small", children: [
      /* @__PURE__ */ jsx(MenuItem, { value: "", children: "All Months" }),
      availableMonths.map((m) => /* @__PURE__ */ jsx(MenuItem, { value: m, children: m }, m))
    ] }) }),
    /* @__PURE__ */ jsx(TableContainer, { component: Paper, className: "mt-4", children: /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: "Date" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Clock In Lat" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Clock In Long" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: log.attendances && log.attendances.length > 0 ? log.attendances.map((attendance, index) => /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: attendance.date }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.clock_in_lat }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.clock_in_long }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.status })
      ] }, index)) : /* @__PURE__ */ jsx(TableRow, { children: /* @__PURE__ */ jsx(TableCell, { colSpan: 4, align: "center", children: "No attendance data available" }) }) })
    ] }) })
  ] });
}
Detail.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Attendance Detail" });
export {
  Detail as default
};
