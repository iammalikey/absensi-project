import { jsxs, jsx } from "react/jsx-runtime";
import { t as tokens } from "./Notification-dd8222ef.js";
import { usePage, Link } from "@inertiajs/react";
import { useMediaQuery, useTheme, Box, Typography, Stack, Card, Button, CardContent } from "@mui/material";
import { useState, useEffect } from "react";
import { H as Header, h as hasAnyPermission, B as Backend } from "./Header-053b50f1.js";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts.js";
import BadgeIcon from "@mui/icons-material/Badge.js";
import EditOffIcon from "@mui/icons-material/EditOff.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
const Index = (props) => {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const [count, setCount] = useState({
    users_count: props.users_count,
    roles_count: props.roles_count,
    permissions_count: props.permissions_count
  });
  const user = usePage().props.auth.user;
  useEffect(() => {
    const fetchData = async () => {
      const updatedData = await fetchUpdatedData();
      setCount(updatedData.data);
    };
    const pollingInterval = setInterval(fetchData, 5e3);
    return () => {
      clearInterval(pollingInterval);
    };
  }, []);
  const fetchUpdatedData = async () => {
    const response = await fetch(route("cms.dashboard", { p: props.pol }));
    const updatedData = await response.json();
    return updatedData;
  };
  return /* @__PURE__ */ jsxs(Box, { sx: { m: "20px" }, children: [
    /* @__PURE__ */ jsx(
      Header,
      {
        title: `Welcome Back ${user.name}`,
        subtitle: `Your Role ${user.role.map(
          (role, index) => role.name
        )}`
      }
    ),
    /* @__PURE__ */ jsx(Typography, { variant: "h2", sx: { fontSize: 25 }, gutterBottom: true, children: "Dashbboard" }),
    hasAnyPermission([
      "user management",
      "role management",
      "permission management",
      "klasemen management"
    ]) && /* @__PURE__ */ jsx(
      Stack,
      {
        sx: { mt: 2 },
        direction: { xs: "column", lg: "row" },
        spacing: 2,
        flexWrap: "no-wrap",
        useFlexGap: true,
        children: /* @__PURE__ */ jsxs(Box, { sx: { width: "100%" }, children: [
          /* @__PURE__ */ jsx(
            Typography,
            {
              variant: "h2",
              sx: { fontSize: 25, mt: 5 },
              gutterBottom: true,
              children: "User, Permission, Role Management"
            }
          ),
          /* @__PURE__ */ jsxs(
            Stack,
            {
              direction: "row",
              spacing: 2,
              flex: isNonMobile ? "no-wrap" : "wrap",
              useFlexGap: true,
              children: [
                /* @__PURE__ */ jsxs(
                  Stack,
                  {
                    direction: "column",
                    spacing: 2,
                    flexGrow: 1,
                    children: [
                      /* @__PURE__ */ jsx(
                        Card,
                        {
                          sx: {
                            minWidth: 275,
                            backgroundColor: colors.primary[400],
                            flexGrow: 1
                          },
                          children: /* @__PURE__ */ jsx(Link, { href: route("cms.access.user.index"), children: /* @__PURE__ */ jsx(
                            Button,
                            {
                              sx: {
                                width: "100%",
                                height: "100%"
                              },
                              children: /* @__PURE__ */ jsxs(CardContent, { children: [
                                /* @__PURE__ */ jsxs(
                                  Typography,
                                  {
                                    sx: { fontSize: 20 },
                                    color: "text.secondary",
                                    children: [
                                      /* @__PURE__ */ jsx(ManageAccountsIcon, {}),
                                      " ",
                                      /* @__PURE__ */ jsx("span", { children: "Users" })
                                    ]
                                  }
                                ),
                                /* @__PURE__ */ jsx(
                                  Typography,
                                  {
                                    sx: { fontSize: 20 },
                                    color: "text.secondary",
                                    align: "center",
                                    children: count.users_count
                                  }
                                )
                              ] })
                            }
                          ) })
                        }
                      ),
                      /* @__PURE__ */ jsx(
                        Card,
                        {
                          sx: {
                            minWidth: 275,
                            backgroundColor: colors.primary[400],
                            flexGrow: 1
                          },
                          children: /* @__PURE__ */ jsx(Link, { href: route("cms.access.role.index"), children: /* @__PURE__ */ jsx(
                            Button,
                            {
                              sx: {
                                width: "100%",
                                height: "100%"
                              },
                              children: /* @__PURE__ */ jsxs(CardContent, { children: [
                                /* @__PURE__ */ jsxs(
                                  Typography,
                                  {
                                    sx: { fontSize: 20 },
                                    color: "text.secondary",
                                    children: [
                                      /* @__PURE__ */ jsx(BadgeIcon, {}),
                                      " ",
                                      /* @__PURE__ */ jsx("span", { children: "Roles" })
                                    ]
                                  }
                                ),
                                /* @__PURE__ */ jsx(
                                  Typography,
                                  {
                                    sx: { fontSize: 20 },
                                    color: "text.secondary",
                                    align: "center",
                                    children: count.roles_count
                                  }
                                )
                              ] })
                            }
                          ) })
                        }
                      )
                    ]
                  }
                ),
                /* @__PURE__ */ jsx(Box, { sx: { flexGrow: 1 }, children: /* @__PURE__ */ jsx(
                  Card,
                  {
                    sx: {
                      minWidth: 275,
                      height: "100%",
                      backgroundColor: colors.primary[400],
                      flexGrow: 1
                    },
                    children: /* @__PURE__ */ jsx(
                      Link,
                      {
                        href: route(
                          "cms.access.permission.index"
                        ),
                        children: /* @__PURE__ */ jsx(
                          Button,
                          {
                            sx: {
                              width: "100%",
                              height: "100%"
                            },
                            children: /* @__PURE__ */ jsxs(CardContent, { children: [
                              /* @__PURE__ */ jsxs(
                                Typography,
                                {
                                  sx: { fontSize: 20 },
                                  color: "text.secondary",
                                  children: [
                                    /* @__PURE__ */ jsx(EditOffIcon, {}),
                                    " ",
                                    /* @__PURE__ */ jsx("span", { children: "Permissions" })
                                  ]
                                }
                              ),
                              /* @__PURE__ */ jsx(
                                Typography,
                                {
                                  sx: {
                                    fontSize: 50,
                                    mt: 4
                                  },
                                  color: "text.secondary",
                                  align: "center",
                                  gutterBottom: true,
                                  children: count.permissions_count
                                }
                              )
                            ] })
                          }
                        )
                      }
                    )
                  }
                ) })
              ]
            }
          )
        ] })
      }
    ),
    !hasAnyPermission([
      "user management",
      "permission management",
      "role management",
      "klasemen management",
      "klasemen management link",
      "klasemen management score",
      "setting management"
    ]) && /* @__PURE__ */ jsx(
      Typography,
      {
        color: colors.redAccent[500],
        variant: "h3",
        sx: { fontSize: 22 },
        align: "center",
        children: "Anda Belum Memiliki Permission Untuk Management Pada System CMS Ini."
      }
    )
  ] });
};
Index.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Dashboard CMS" });
export {
  Index as default
};
