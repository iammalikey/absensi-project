import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, FormControl, InputLabel, Select, MenuItem, TextField, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Create({ users, divisions, maritalStatuses, religions }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, reset, errors, post } = useForm({
    user_id: "",
    division_id: "",
    full_name: "",
    place_of_birth: "",
    date_of_birth: "",
    blood_type: "",
    address: "",
    nik: "",
    npwp: "",
    postal_code: "",
    marital_status: "",
    religion: ""
  });
  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.employee.store"), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: () => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Create Employee", subtitle: "Create New Employee Data" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: [
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "User" }),
              /* @__PURE__ */ jsx(Select, { name: "user_id", value: data.user_id, onChange: handleChange, children: users.map((user) => /* @__PURE__ */ jsx(MenuItem, { value: user.id, children: user.name }, user.id)) })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "Division" }),
              /* @__PURE__ */ jsx(Select, { name: "division_id", value: data.division_id, onChange: handleChange, children: divisions.map((division) => /* @__PURE__ */ jsx(MenuItem, { value: division.id, children: division.title }, division.id)) })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "Marital Status" }),
              /* @__PURE__ */ jsx(Select, { name: "marital_status", value: data.marital_status, onChange: handleChange, children: maritalStatuses.map((status) => /* @__PURE__ */ jsx(MenuItem, { value: status, children: status }, status)) }),
              errors.marital_status && /* @__PURE__ */ jsx("p", { className: "text-red-500", children: errors.marital_status })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "Religion" }),
              /* @__PURE__ */ jsx(Select, { name: "religion", value: data.religion, onChange: handleChange, children: religions.map((religion) => /* @__PURE__ */ jsx(MenuItem, { value: religion, children: religion }, religion)) }),
              errors.religion && /* @__PURE__ */ jsx("p", { className: "text-red-500", children: errors.religion })
            ] }),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Full Name",
                onChange: handleChange,
                name: "full_name",
                value: data.full_name,
                error: !!errors.full_name,
                helperText: errors.full_name,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Place of Birth",
                onChange: handleChange,
                name: "place_of_birth",
                value: data.place_of_birth,
                error: !!errors.place_of_birth,
                helperText: errors.place_of_birth,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "date",
                label: "Date of Birth",
                onChange: handleChange,
                name: "date_of_birth",
                value: data.date_of_birth,
                InputLabelProps: { shrink: true },
                error: !!errors.date_of_birth,
                helperText: errors.date_of_birth,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Blood Type",
                onChange: handleChange,
                name: "blood_type",
                value: data.blood_type,
                error: !!errors.blood_type,
                helperText: errors.blood_type,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Address",
                onChange: handleChange,
                name: "address",
                multiline: true,
                rows: 3,
                value: data.address,
                error: !!errors.address,
                helperText: errors.address,
                sx: { gridColumn: "span 4" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "NIK",
                onChange: handleChange,
                name: "nik",
                value: data.nik,
                error: !!errors.nik,
                helperText: errors.nik,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "NPWP",
                onChange: handleChange,
                name: "npwp",
                value: data.npwp,
                error: !!errors.npwp,
                helperText: errors.npwp,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Postal Code",
                onChange: handleChange,
                name: "postal_code",
                value: data.postal_code,
                error: !!errors.postal_code,
                helperText: errors.postal_code,
                sx: { gridColumn: "span 2" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Create.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Create Employee" });
export {
  Create as default
};
