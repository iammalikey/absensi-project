import { jsxs, jsx } from "react/jsx-runtime";
import { usePage, useForm } from "@inertiajs/react";
import { useMediaQuery, Box, Avatar, TextField, Button } from "@mui/material";
import { useState } from "react";
import { H as Header, c as createUrlImage, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Index() {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { auth: { user } } = usePage().props;
  const { data, setData, reset, errors, post } = useForm({
    name: user.name,
    username: user.username,
    email: user.email,
    _method: "put"
  });
  const [avatarUrl, setAvatarUrl] = useState(user.avatar);
  const handleChange = (e) => {
    setData((prevData) => ({ ...prevData, [e.target.name]: e.target.value }));
  };
  const handleChangeImage = (e) => {
    setData((prevData) => ({ ...prevData, [e.target.name]: e.target.files[0] }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.profile.update"), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: (page) => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `Profile`, subtitle: `Update ${user.name} profile` }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": { gridColumn: isNonMobile ? void 0 : "span 4" }
          },
          children: [
            /* @__PURE__ */ jsx(
              Box,
              {
                display: "flex",
                justifyContent: "center",
                sx: { gridColumn: "span 4" },
                children: /* @__PURE__ */ jsxs("label", { htmlFor: "avatar_upload", tabIndex: 0, children: [
                  /* @__PURE__ */ jsx(Avatar, { sx: { width: 100, height: 100, cursor: "pointer" }, src: avatarUrl }),
                  /* @__PURE__ */ jsx("input", { tabIndex: 1, type: "file", id: "avatar_upload", hidden: true, onInput: (e) => {
                    handleChangeImage(e);
                    setAvatarUrl(createUrlImage(e));
                  }, name: "avatar", accept: "image/png" })
                ] })
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Name",
                onChange: handleChange,
                name: "name",
                value: data.name,
                error: !!errors.name,
                helperText: errors.name,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                disabled: true,
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Username",
                onChange: handleChange,
                name: "username",
                value: data.username,
                error: !!errors.username,
                helperText: errors.username,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                disabled: true,
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Email",
                onChange: handleChange,
                name: "email",
                value: data.email,
                error: !!errors.email,
                helperText: errors.email,
                sx: { gridColumn: "span 4" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Update" }) })
    ] })
  ] });
}
Index.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Profile" });
export {
  Index as default
};
