import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, TextField, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Edit({ division }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, errors, post } = useForm({
    title: division.data.title,
    _method: "put"
  });
  const handleChange = (e) => {
    setData((prevData) => ({ ...prevData, [e.target.name]: e.target.value }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.division.update", { division: division.data.slug }), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: (page) => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `Edit Division`, subtitle: `Edit Division ${division.data.title}` }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsx(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: /* @__PURE__ */ jsx(
            TextField,
            {
              fullWidth: true,
              variant: "filled",
              type: "text",
              label: "Title",
              onChange: handleChange,
              name: "title",
              value: data.title,
              error: !!errors.title,
              helperText: errors.title,
              sx: { gridColumn: "span 4" }
            }
          )
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Edit.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Edit Division" });
export {
  Edit as default
};
