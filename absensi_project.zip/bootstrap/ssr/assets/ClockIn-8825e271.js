import { jsx, jsxs } from "react/jsx-runtime";
import { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
/* empty css                  */import L from "leaflet";
import { router } from "@inertiajs/react";
import { M as MainLayout } from "./MainLayout-98c8587a.js";
import Swal from "sweetalert2";
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png"
});
const ClockIn = () => {
  const [category, setCategory] = useState("WFH");
  const [currentDateTime, setCurrentDateTime] = useState("");
  const [position, setPosition] = useState(null);
  useEffect(() => {
    const now = /* @__PURE__ */ new Date();
    setCurrentDateTime(now.toLocaleString());
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setPosition([pos.coords.latitude, pos.coords.longitude]);
        },
        (err) => {
          console.error("Error fetching location:", err);
        },
        { enableHighAccuracy: true }
      );
    } else {
      console.error("Geolocation not supported");
    }
  }, []);
  const handleSubmit = (e) => {
    e.preventDefault();
    const now = /* @__PURE__ */ new Date();
    const formattedDateTime = now.toISOString().slice(0, 19).replace("T", " ");
    const data = {
      category,
      clock_in: formattedDateTime,
      latitude: position ? position[0] : null,
      longitude: position ? position[1] : null
    };
    router.post("/attendance/clockin", data, {
      preserveScroll: true,
      onSuccess: (page) => {
        Swal.fire({
          title: "Clock In Berhasil!",
          text: page.props.flash.message || "Berhasil Clock In!",
          icon: "success"
        });
      },
      onError: (errors) => {
        Swal.fire({
          title: "Gagal Clock In",
          text: errors.message || "Terjadi kesalahan saat Clock In!",
          icon: "error"
        });
      }
    });
  };
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen p-4 bg-gray-100", children: /* @__PURE__ */ jsxs("div", { className: "max-w-lg p-6 mx-auto bg-white rounded shadow", children: [
    /* @__PURE__ */ jsx("h1", { className: "mb-4 text-2xl font-bold", children: "Attendance Clock In" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "block text-gray-700", children: "Category" }),
        /* @__PURE__ */ jsxs(
          "select",
          {
            value: category,
            onChange: (e) => setCategory(e.target.value),
            className: "block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-gray-500 focus:border-gray-500",
            children: [
              /* @__PURE__ */ jsx("option", { value: "WFH", children: "WFH" }),
              /* @__PURE__ */ jsx("option", { value: "WFO", children: "WFO" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "block text-gray-700", children: "Date & Time" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            type: "text",
            value: currentDateTime,
            disabled: true,
            className: "block w-full mt-1 bg-gray-100 border-gray-300 rounded-md shadow-sm focus:ring-gray-500 focus:border-gray-500"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { className: "block mb-2 text-gray-700", children: "Current Location" }),
        position ? /* @__PURE__ */ jsxs(
          MapContainer,
          {
            center: position,
            zoom: 13,
            style: { height: "300px", width: "100%" },
            children: [
              /* @__PURE__ */ jsx(
                TileLayer,
                {
                  attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                  url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                }
              ),
              /* @__PURE__ */ jsx(Marker, { position, children: /* @__PURE__ */ jsx(Popup, { children: "You are here." }) })
            ]
          }
        ) : /* @__PURE__ */ jsx("p", { children: "Loading map..." })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          type: "submit",
          className: "w-full px-4 py-2 text-white bg-gray-500 rounded hover:bg-gray-600",
          children: "Clock In"
        }
      )
    ] })
  ] }) });
};
ClockIn.layout = (page) => /* @__PURE__ */ jsx(MainLayout, { children: page, title: "ClockIn" });
export {
  ClockIn as default
};
