import { jsxs, jsx } from "react/jsx-runtime";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import { useMediaQuery, Box, TextField, Button } from "@mui/material";
import { usePage, useForm } from "@inertiajs/react";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function ChangePassword() {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { auth } = usePage().props;
  const { data, setData, reset, errors, put } = useForm({});
  const handleChange = (e) => {
    setData((prevData) => ({ ...prevData, [e.target.name]: e.target.value }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    put(route("cms.profile.password.update"), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: (page) => {
        reset();
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `Change Password`, subtitle: `Change ${auth.user.name} password` }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": { gridColumn: isNonMobile ? void 0 : "span 4" }
          },
          children: [
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "password",
                label: "Old Password",
                onChange: handleChange,
                name: "old_password",
                error: !!errors.old_password,
                helperText: errors.old_password,
                sx: { gridColumn: "span 4" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "password",
                label: "Password",
                onChange: handleChange,
                name: "password",
                error: !!errors.password,
                helperText: errors.password,
                sx: { gridColumn: "span 4" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "password",
                label: "Password Confirmation",
                onChange: handleChange,
                name: "password_confirmation",
                error: !!errors.password_confirmation,
                helperText: errors.password_confirmation,
                sx: { gridColumn: "span 4" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
ChangePassword.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Change Password" });
export {
  ChangePassword as default
};
