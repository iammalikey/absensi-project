import { jsxs, jsx } from "react/jsx-runtime";
import "react";
import Button from "@mui/material/Button/index.js";
import Dialog from "@mui/material/Dialog/index.js";
import DialogActions from "@mui/material/DialogActions/index.js";
import DialogContent from "@mui/material/DialogContent/index.js";
import DialogContentText from "@mui/material/DialogContentText/index.js";
import DialogTitle from "@mui/material/DialogTitle/index.js";
import { router } from "@inertiajs/react";
function ConfirmDeleteDialog({ arrUser, openConfirmDelete, setOpenConfirmDelete, isBulkDelete, setIsBulkDelete, route }) {
  const handleClose = () => {
    setOpenConfirmDelete(false);
  };
  const handleDelete = () => {
    if (!isBulkDelete) {
      router.delete(route, {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          setOpenConfirmDelete(false);
        }
      });
    } else {
      router.post(route, { id: arrUser }, {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          setIsBulkDelete(false);
          setOpenConfirmDelete(false);
        }
      });
    }
  };
  return /* @__PURE__ */ jsxs(
    Dialog,
    {
      open: openConfirmDelete,
      onClose: handleClose,
      "aria-labelledby": "alert-dialog-title",
      "aria-describedby": "alert-dialog-description",
      children: [
        /* @__PURE__ */ jsx(DialogTitle, { id: "alert-dialog-title", children: "Delete Action" }),
        /* @__PURE__ */ jsx(DialogContent, { children: /* @__PURE__ */ jsx(DialogContentText, { id: "alert-dialog-description", children: "Are you sure to continue this action ?" }) }),
        /* @__PURE__ */ jsxs(DialogActions, { children: [
          /* @__PURE__ */ jsx(Button, { color: "neutral", onClick: handleClose, autoFocus: true, children: "Cancel" }),
          /* @__PURE__ */ jsx(Button, { color: "danger", onClick: handleDelete, children: "Yes" })
        ] })
      ]
    }
  );
}
export {
  ConfirmDeleteDialog as C
};
