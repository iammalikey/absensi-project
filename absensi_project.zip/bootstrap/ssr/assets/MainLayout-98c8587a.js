import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { usePage, router } from "@inertiajs/react";
function NavBar() {
  useState(false);
  const { auth } = usePage().props;
  const handleLogout = (e) => {
    e.preventDefault();
    router.post("/logout");
  };
  const goToDashboard = () => {
    router.visit("/dashboard");
  };
  return /* @__PURE__ */ jsx("nav", { className: "bg-white shadow", children: /* @__PURE__ */ jsx("div", { className: "px-4 mx-auto max-w-7xl", children: /* @__PURE__ */ jsxs("div", { className: "flex justify-between h-16", children: [
    /* @__PURE__ */ jsx("div", { className: "flex items-center cursor-pointer", onClick: goToDashboard, children: /* @__PURE__ */ jsx("img", { src: "/assets/images/concrete-logo.png", alt: "concrete logo", className: "object-contain w-10 h-10" }) }),
    /* @__PURE__ */ jsx("div", { className: "flex items-center", children: (auth == null ? void 0 : auth.user) ? /* @__PURE__ */ jsx(Fragment, { children: /* @__PURE__ */ jsxs(
      "button",
      {
        onClick: handleLogout,
        className: "block w-full px-4 py-2 text-sm text-left text-gray-700",
        children: [
          /* @__PURE__ */ jsx("span", { className: "font-bold", children: "Logout" }),
          ",  ",
          /* @__PURE__ */ jsx("span", { className: "font-extrabold", children: auth.user.name || "User" })
        ]
      }
    ) }) : null })
  ] }) }) });
}
function MainLayout({ children }) {
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-gray-100", children: [
    /* @__PURE__ */ jsx(NavBar, {}),
    /* @__PURE__ */ jsx("main", { className: "p-4", children })
  ] });
}
export {
  MainLayout as M
};
