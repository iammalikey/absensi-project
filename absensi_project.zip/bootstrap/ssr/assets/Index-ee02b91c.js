import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import { Box, TextField, Button, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, TablePagination } from "@mui/material";
import { router } from "@inertiajs/react";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Index({ attendances, selectedMonth, selectedName }) {
  const [month, setMonth] = useState(selectedMonth);
  const [name, setName] = useState(selectedName);
  const handleFilter = () => {
    router.get(route("cms.log.index"), { month, name });
  };
  const handleChangePage = (event, newPage) => {
    var _a;
    router.get((_a = attendances.links[newPage + 1]) == null ? void 0 : _a.url, {}, { preserveScroll: true });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Attendance Log", subtitle: "Monthly Attendance Report" }),
    /* @__PURE__ */ jsxs(Box, { display: "flex", alignItems: "center", gap: "10px", mb: "20px", children: [
      /* @__PURE__ */ jsx(
        TextField,
        {
          type: "month",
          value: month,
          onChange: (e) => setMonth(e.target.value),
          label: "Select Month"
        }
      ),
      /* @__PURE__ */ jsx(
        TextField,
        {
          type: "text",
          value: name,
          onChange: (e) => setName(e.target.value),
          label: "Search by Name"
        }
      ),
      /* @__PURE__ */ jsx(Button, { variant: "contained", color: "primary", onClick: handleFilter, children: "Filter" })
    ] }),
    /* @__PURE__ */ jsx(
      Button,
      {
        variant: "contained",
        color: "secondary",
        onClick: () => window.location.href = route("cms.log.export", { month, name }),
        children: "Export to Excel"
      }
    ),
    /* @__PURE__ */ jsx(TableContainer, { sx: { maxHeight: "70vh" }, children: /* @__PURE__ */ jsxs(Table, { stickyHeader: true, "aria-label": "sticky table", children: [
      /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: "Employee" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Clock In" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Clock Out" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Radius (KM)" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Status" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: attendances.data.map((attendance) => /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: attendance.user.name }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.clock_in }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.clock_out || "-" }),
        /* @__PURE__ */ jsxs(TableCell, { children: [
          attendance.distance.toFixed(2),
          " KM"
        ] }),
        /* @__PURE__ */ jsx(TableCell, { children: attendance.status })
      ] }, attendance.id)) })
    ] }) }),
    /* @__PURE__ */ jsx(
      TablePagination,
      {
        rowsPerPageOptions: [10, 20, 50],
        component: "div",
        count: attendances.total,
        rowsPerPage: attendances.per_page,
        page: attendances.current_page - 1,
        onPageChange: handleChangePage
      }
    )
  ] });
}
Index.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Attendance Log" });
export {
  Index as default
};
