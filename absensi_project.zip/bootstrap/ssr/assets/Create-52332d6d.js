import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, FormControl, InputLabel, Select, MenuItem, TextField, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Create({ users, categories, statuses }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, reset, errors, post } = useForm({
    user_id: "",
    date: "",
    clock_in: "",
    clock_out: "",
    clock_in_lat: "",
    clock_in_long: "",
    category: "",
    status: ""
  });
  const handleChange = (e) => {
    let { name, value } = e.target;
    if (name === "clock_in" || name === "clock_out") {
      const date = new Date(value);
      value = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:00`;
    }
    setData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.attendance.store"), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: () => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Create attendance", subtitle: "Create New attendance Data" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: [
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "User" }),
              /* @__PURE__ */ jsx(Select, { name: "user_id", value: data.user_id, onChange: handleChange, children: users.map((user) => /* @__PURE__ */ jsx(MenuItem, { value: user.id, children: user.name }, user.id)) })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "Category" }),
              /* @__PURE__ */ jsx(Select, { name: "category", value: data.category, onChange: handleChange, children: categories.map((item) => /* @__PURE__ */ jsx(MenuItem, { value: item, children: item }, item)) })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { fullWidth: true, variant: "filled", sx: { gridColumn: "span 2" }, children: [
              /* @__PURE__ */ jsx(InputLabel, { children: "Status" }),
              /* @__PURE__ */ jsx(Select, { name: "status", value: data.status, onChange: handleChange, children: statuses.map((status) => /* @__PURE__ */ jsx(MenuItem, { value: status, children: status }, status)) }),
              errors.status && /* @__PURE__ */ jsx("p", { className: "text-red-500", children: errors.status })
            ] }),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "datetime-local",
                label: "Clock In",
                onChange: handleChange,
                name: "clock_in",
                value: data.clock_in,
                InputLabelProps: { shrink: true },
                error: !!errors.clock_in,
                helperText: errors.clock_in,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "datetime-local",
                label: "Clock Out",
                onChange: handleChange,
                name: "clock_out",
                value: data.clock_out,
                InputLabelProps: { shrink: true },
                error: !!errors.clock_out,
                helperText: errors.clock_out,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "clock_in_lat",
                onChange: handleChange,
                name: "clock_in_lat",
                value: data.clock_in_lat,
                error: !!errors.clock_in_lat,
                helperText: errors.clock_in_lat,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "clock_in_long",
                onChange: handleChange,
                name: "clock_in_long",
                value: data.clock_in_long,
                error: !!errors.clock_in_long,
                helperText: errors.clock_in_long,
                sx: { gridColumn: "span 2" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Create.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Create attendance" });
export {
  Create as default
};
