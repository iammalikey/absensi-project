import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, FormControl, InputLabel, Select, MenuItem, TextField, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Edit({ employee, users, divisions, maritalStatuses, religions }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, errors, post } = useForm({
    user_id: employee.data.user_id,
    division_id: employee.data.division_id,
    full_name: employee.data.full_name,
    place_of_birth: employee.data.place_of_birth,
    date_of_birth: employee.data.date_of_birth,
    blood_type: employee.data.blood_type,
    address: employee.data.address,
    nik: employee.data.nik,
    npwp: employee.data.npwp,
    postal_code: employee.data.postal_code,
    marital_status: employee.data.marital_status,
    religion: employee.data.religion,
    _method: "put"
  });
  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.employee.update", { employee: employee.data.slug }), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: () => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Edit Employee", subtitle: `Edit Employee ${data.full_name}` }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: [
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.user_id, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "user-label", children: "Select User" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "user-label",
                  id: "user_id",
                  value: data.user_id,
                  name: "user_id",
                  onChange: handleChange,
                  renderValue: (selected) => {
                    const selectedUser = users.find((user) => user.id === selected);
                    return selectedUser ? selectedUser.name : "Select User";
                  },
                  children: users && users.map((user) => /* @__PURE__ */ jsx(MenuItem, { value: user.id, children: user.name }, user.id))
                }
              ),
              !!errors.user_id && /* @__PURE__ */ jsx(FormHelperText, { error: !!errors.user_id, children: errors.user_id })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.division_id, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "user-label", children: "Select Division" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "user-label",
                  id: "division_id",
                  value: data.division_id,
                  name: "division_id",
                  onChange: handleChange,
                  renderValue: (selected) => {
                    const selectedDivision = divisions.find((division) => division.id === selected);
                    return selectedDivision ? selectedDivision.title : "Select User";
                  },
                  children: divisions && divisions.map((division) => /* @__PURE__ */ jsx(MenuItem, { value: division.id, children: division.title }, division.id))
                }
              ),
              !!errors.division_id && /* @__PURE__ */ jsx(FormHelperText, { error: !!errors.division_id, children: errors.division_id })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.marital_status, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "marital-status-label", children: "Marital Status" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "marital-status-label",
                  id: "marital_status",
                  value: data.marital_status,
                  name: "marital_status",
                  onChange: handleChange,
                  renderValue: (selected) => selected || "Select Marital Status",
                  children: Array.isArray(maritalStatuses) && maritalStatuses.map((status) => /* @__PURE__ */ jsx(MenuItem, { value: status, children: status }, status))
                }
              ),
              !!errors.marital_status && /* @__PURE__ */ jsx(FormHelperText, { children: errors.marital_status })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.religion, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "marital-status-label", children: "Religion" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "marital-status-label",
                  id: "religion",
                  value: data.religion,
                  name: "religion",
                  onChange: handleChange,
                  renderValue: (selected) => selected || "Select Marital Status",
                  children: Array.isArray(religions) && religions.map((status) => /* @__PURE__ */ jsx(MenuItem, { value: status, children: status }, status))
                }
              ),
              !!errors.religion && /* @__PURE__ */ jsx(FormHelperText, { children: errors.religion })
            ] }),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Full Name",
                onChange: handleChange,
                name: "full_name",
                value: data.full_name,
                error: !!errors.full_name,
                helperText: errors.full_name,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Place of Birth",
                onChange: handleChange,
                name: "place_of_birth",
                value: data.place_of_birth,
                error: !!errors.place_of_birth,
                helperText: errors.place_of_birth,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "date",
                label: "Date of Birth",
                onChange: handleChange,
                name: "date_of_birth",
                value: data.date_of_birth,
                InputLabelProps: { shrink: true },
                error: !!errors.date_of_birth,
                helperText: errors.date_of_birth,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Blood Type",
                onChange: handleChange,
                name: "blood_type",
                value: data.blood_type,
                error: !!errors.blood_type,
                helperText: errors.blood_type,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Address",
                onChange: handleChange,
                name: "address",
                multiline: true,
                rows: 3,
                value: data.address,
                error: !!errors.address,
                helperText: errors.address,
                sx: { gridColumn: "span 4" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "NIK",
                onChange: handleChange,
                name: "nik",
                value: data.nik,
                error: !!errors.nik,
                helperText: errors.nik,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "NPWP",
                onChange: handleChange,
                name: "npwp",
                value: data.npwp,
                error: !!errors.npwp,
                helperText: errors.npwp,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Postal Code",
                onChange: handleChange,
                name: "postal_code",
                value: data.postal_code,
                error: !!errors.postal_code,
                helperText: errors.postal_code,
                sx: { gridColumn: "span 2" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Edit.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Edit Employee" });
export {
  Edit as default
};
