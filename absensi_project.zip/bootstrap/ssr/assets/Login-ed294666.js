import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import "react";
function Login() {
  const { data, setData, post, processing, errors } = useForm({
    email: "",
    password: ""
  });
  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post("/login", {
      preserveScroll: true
    });
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center justify-center min-h-screen bg-gray-100 p-5", children: [
    /* @__PURE__ */ jsx("img", { src: "/assets/images/concrete-logo.png", alt: "concrete logo", className: "object-contain w-28 h-28 mb-5" }),
    /* @__PURE__ */ jsx("span", { className: "ml-5 font-bold uppercase mb-10 text-2xl", children: "CONCRETE CLOCK IN" }),
    /* @__PURE__ */ jsx("div", { className: "w-full max-w-md p-8 bg-white rounded shadow-md", children: /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "email", className: "block text-gray-700", children: "Email" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            id: "email",
            name: "email",
            type: "email",
            value: data.email,
            onChange: handleChange,
            className: "block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500",
            required: true
          }
        ),
        errors.email && /* @__PURE__ */ jsx("div", { className: "mt-1 text-red-500", children: errors.email })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx("label", { htmlFor: "password", className: "block text-gray-700", children: "Password" }),
        /* @__PURE__ */ jsx(
          "input",
          {
            id: "password",
            name: "password",
            type: "password",
            value: data.password,
            onChange: handleChange,
            className: "block w-full mt-1 border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500",
            required: true
          }
        ),
        errors.password && /* @__PURE__ */ jsx("div", { className: "mt-1 text-red-500", children: errors.password })
      ] }),
      /* @__PURE__ */ jsx(
        "button",
        {
          disabled: processing,
          type: "submit",
          className: "w-full px-4 py-2 text-white bg-gray-900 rounded hover:bg-gray-600",
          children: "Login"
        }
      )
    ] }) })
  ] });
}
export {
  Login as default
};
