import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, TextField, FormControl, InputLabel, Select, Chip, MenuItem, FormHelperText, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Create({ permissions }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, reset, errors, post } = useForm({
    name: "",
    permissions: []
  });
  const handleChange = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.access.role.store"), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: (page) => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `Create Role`, subtitle: `Create new role` }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: [
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "Name",
                onChange: handleChange,
                name: "name",
                value: data.name,
                error: !!errors.name,
                helperText: errors.name,
                sx: { gridColumn: "span 4" }
              }
            ),
            /* @__PURE__ */ jsxs(
              FormControl,
              {
                variant: "filled",
                sx: { gridColumn: "span 4" },
                error: !!errors.permissions,
                children: [
                  /* @__PURE__ */ jsx(InputLabel, { id: "permissions-label", variant: "filled", children: "Select Roles" }),
                  /* @__PURE__ */ jsx(
                    Select,
                    {
                      labelId: "permissions-label",
                      id: "permissions",
                      multiple: true,
                      value: data.permissions,
                      name: "permissions",
                      onChange: handleChange,
                      renderValue: (selected) => /* @__PURE__ */ jsx(
                        Box,
                        {
                          sx: {
                            display: "flex",
                            flexWrap: "wrap",
                            gap: 0.5
                          },
                          children: selected.map((value) => /* @__PURE__ */ jsx(Chip, { label: value }, value))
                        }
                      ),
                      children: permissions.map((permission, index) => /* @__PURE__ */ jsx(
                        MenuItem,
                        {
                          value: permission.name,
                          children: permission.name
                        },
                        permission.id + index
                      ))
                    }
                  ),
                  !!errors.permissions && /* @__PURE__ */ jsx(FormHelperText, { error: !!errors.permissions, children: errors.permissions })
                ]
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Create.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Create Role" });
export {
  Create as default
};
