import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useState, useMemo, useContext } from "react";
import { usePage, router, Link, Head } from "@inertiajs/react";
import { useTheme, useMediaQuery, Box, IconButton, Typography, Tooltip, Avatar, Menu as Menu$1, MenuItem as MenuItem$1, Divider, ListItemIcon, ThemeProvider, CssBaseline } from "@mui/material";
import { t as tokens, C as ColorModeContext, u as useMode, N as Notification } from "./Notification-dd8222ef.js";
import { ProSidebar, Menu, MenuItem } from "react-pro-sidebar";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined.js";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined.js";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts.js";
import HomeWorkOutlinedIcon from "@mui/icons-material/HomeWorkOutlined.js";
import GroupOutlinedIcon from "@mui/icons-material/GroupOutlined.js";
import ManageHistoryOutlinedIcon from "@mui/icons-material/ManageHistoryOutlined.js";
import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined.js";
import BadgeIcon from "@mui/icons-material/Badge.js";
import EditOffIcon from "@mui/icons-material/EditOff.js";
import InputBase from "@mui/material/InputBase/index.js";
import SearchIcon from "@mui/icons-material/Search.js";
import { Settings, Logout } from "@mui/icons-material";
import { SnackbarProvider } from "notistack";
const styles = "";
const getUrlSearchParameter = (query) => new URLSearchParams(window.location.search).get(query);
const createUrlImage = (e, originUrl = null) => e.target.files[0] ? URL.createObjectURL(e.target.files[0]) : originUrl || defaultImage;
const defaultImage = "/assets/default/image_default.png";
const hasAnyPermission = (permissions = null) => {
  const allPermissions = usePage().props.auth.user.can;
  let hasPermission = false;
  permissions == null ? void 0 : permissions.forEach(function(item) {
    if (allPermissions[item])
      hasPermission = true;
  });
  const roles = usePage().props.auth.user.role;
  roles == null ? void 0 : roles.forEach(function(item) {
    if (item.name == "Super Admin")
      hasPermission = true;
  });
  return hasPermission;
};
const Item = ({ title, to, icon, url }) => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return /* @__PURE__ */ jsxs(
    MenuItem,
    {
      active: url.startsWith(new URL(to).pathname),
      style: { color: colors.grey[100] },
      icon,
      children: [
        /* @__PURE__ */ jsx(Typography, { children: title }),
        /* @__PURE__ */ jsx(Link, { href: to })
      ]
    }
  );
};
const Sidebar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const isNonMobile = useMediaQuery("(min-width:900px)");
  const [isCollapsed, setIsCollapsed] = useState(false);
  useMemo(() => {
    setIsCollapsed(isNonMobile ? false : true);
  }, [isNonMobile]);
  const url = usePage().url;
  return /* @__PURE__ */ jsx(
    Box,
    {
      sx: {
        flexShrink: 0,
        width: `${isNonMobile ? isCollapsed ? "80px" : "270px" : "80px"}`,
        transition: "width .4s",
        "& .pro-sidebar": { position: "fixed" },
        "& .pro-sidebar-inner": { background: `${colors.primary[400]} !important` },
        "& .pro-icon-wrapper": { backgroundColor: "transparent !important" },
        "& .pro-inner-item": { padding: `5px ${isCollapsed ? "35px" : "5px"} 5px 20px !important` },
        "& .pro-inner-item:hover": { color: `${colors.danamonAccent[400]} !important` },
        "& .pro-menu-item.active": { color: `${colors.danamonAccent[400]} !important` }
      },
      children: /* @__PURE__ */ jsx(ProSidebar, { collapsed: isCollapsed, children: /* @__PURE__ */ jsxs(Menu, { iconShape: "square", children: [
        /* @__PURE__ */ jsx(
          MenuItem,
          {
            onClick: () => setIsCollapsed(!isCollapsed),
            icon: isCollapsed ? /* @__PURE__ */ jsx(MenuOutlinedIcon, {}) : void 0,
            style: {
              margin: "10px 0 20px 0",
              color: colors.grey[100],
              height: `${isNonMobile ? "60px" : "40px"}`
            },
            children: !isCollapsed && /* @__PURE__ */ jsxs(Box, { display: "flex", justifyContent: "space-between", alignItems: "center", ml: "15px", children: [
              /* @__PURE__ */ jsx("div", { onClick: (e) => {
                e.stopPropagation();
                router.get(route("landing"));
              }, className: "w-max aspect-[11/4] mx-auto my-0 bg-white p-1 rounded-md", children: /* @__PURE__ */ jsx("img", { src: "/assets/images/concrete-logo.png", alt: "concrete logo", className: "object-contain w-full h-full" }) }),
              /* @__PURE__ */ jsx(IconButton, { children: /* @__PURE__ */ jsx(MenuOutlinedIcon, {}) })
            ] })
          }
        ),
        /* @__PURE__ */ jsxs(Box, { paddingLeft: isCollapsed ? void 0 : "10%", children: [
          /* @__PURE__ */ jsx(
            Item,
            {
              title: "Dashboard",
              to: route("cms.dashboard"),
              icon: /* @__PURE__ */ jsx(HomeOutlinedIcon, {}),
              url
            }
          ),
          hasAnyPermission(["division management"]) && /* @__PURE__ */ jsx(
            Item,
            {
              title: "Division",
              to: route("cms.division.index"),
              icon: /* @__PURE__ */ jsx(HomeWorkOutlinedIcon, {}),
              url
            }
          ),
          hasAnyPermission(["employee management"]) && /* @__PURE__ */ jsx(
            Item,
            {
              title: "Employee",
              to: route("cms.employee.index"),
              icon: /* @__PURE__ */ jsx(GroupOutlinedIcon, {}),
              url
            }
          ),
          hasAnyPermission(["attendance management"]) && /* @__PURE__ */ jsx(
            Item,
            {
              title: "Attendance",
              to: route("cms.attendance.index"),
              icon: /* @__PURE__ */ jsx(ManageHistoryOutlinedIcon, {}),
              url
            }
          ),
          hasAnyPermission(["log management"]) && /* @__PURE__ */ jsx(
            Item,
            {
              title: "Log",
              to: route("cms.log.index"),
              icon: /* @__PURE__ */ jsx(BarChartOutlinedIcon, {}),
              url
            }
          ),
          hasAnyPermission(["user management", "role management", "permission management"]) && /* @__PURE__ */ jsxs(Fragment, { children: [
            /* @__PURE__ */ jsx(Typography, { variant: "h6", color: colors.grey[300], sx: { m: "15px 0 5px 20px" }, children: "Access" }),
            hasAnyPermission(["user management"]) && /* @__PURE__ */ jsx(
              Item,
              {
                title: "User",
                to: route("cms.access.user.index"),
                icon: /* @__PURE__ */ jsx(ManageAccountsIcon, {}),
                url
              }
            ),
            hasAnyPermission(["role management"]) && /* @__PURE__ */ jsx(
              Item,
              {
                title: "Role",
                to: route("cms.access.role.index"),
                icon: /* @__PURE__ */ jsx(BadgeIcon, {}),
                url
              }
            ),
            hasAnyPermission(["permission management"]) && /* @__PURE__ */ jsx(
              Item,
              {
                title: "Permission",
                to: route("cms.access.permission.index"),
                icon: /* @__PURE__ */ jsx(EditOffIcon, {}),
                url
              }
            )
          ] })
        ] })
      ] }) })
    }
  );
};
const Topbar = () => {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  useContext(ColorModeContext);
  const { auth } = usePage().props;
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleLogout = () => {
    router.post(route("cms.logout"));
  };
  return /* @__PURE__ */ jsxs(Box, { display: "flex", justifyContent: "space-between", p: 2, children: [
    /* @__PURE__ */ jsxs(
      Box,
      {
        display: "flex",
        alignItems: "center",
        backgroundColor: colors.primary[400],
        borderRadius: "3px",
        padding: "5px",
        children: [
          /* @__PURE__ */ jsx(InputBase, { sx: { ml: 2, flex: 1 }, placeholder: "Search" }),
          /* @__PURE__ */ jsx(
            IconButton,
            {
              type: "button",
              sx: { p: 1, height: "25px", width: "25px" },
              children: /* @__PURE__ */ jsx(SearchIcon, {})
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsx(Box, { display: "flex", children: /* @__PURE__ */ jsx(Tooltip, { title: "Account settings", children: /* @__PURE__ */ jsx(
      IconButton,
      {
        onClick: handleClick,
        "aria-controls": open ? "account-menu" : void 0,
        "aria-haspopup": "true",
        "aria-expanded": open ? "true" : void 0,
        children: /* @__PURE__ */ jsx(
          Avatar,
          {
            src: auth.user.avatar ?? null,
            sx: { width: 35, height: 35 },
            children: auth.user.name[0]
          }
        )
      }
    ) }) }),
    /* @__PURE__ */ jsxs(
      Menu$1,
      {
        anchorEl,
        id: "account-menu",
        open,
        onClose: handleClose,
        onClick: handleClose,
        PaperProps: {
          elevation: 0,
          sx: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatar-root": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 14,
              width: 10,
              height: 10,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0
            }
          }
        },
        transformOrigin: { horizontal: "right", vertical: "top" },
        anchorOrigin: { horizontal: "right", vertical: "bottom" },
        children: [
          /* @__PURE__ */ jsx(MenuItem$1, { onClick: handleClose, children: /* @__PURE__ */ jsxs(
            Link,
            {
              href: route("cms.profile.edit"),
              className: "flex items-center w-full h-8",
              children: [
                /* @__PURE__ */ jsx(Avatar, { src: auth.user.avatar ?? null, children: auth.user.name[0] }),
                /* @__PURE__ */ jsx(Typography, { className: "text-base font-bold", children: auth.user.name })
              ]
            }
          ) }),
          /* @__PURE__ */ jsx(Divider, {}),
          /* @__PURE__ */ jsxs(
            MenuItem$1,
            {
              onClick: () => {
                router.get(route("cms.profile.password.edit"));
              },
              children: [
                /* @__PURE__ */ jsx(ListItemIcon, { children: /* @__PURE__ */ jsx(Settings, { fontSize: "small" }) }),
                "Change password"
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            MenuItem$1,
            {
              onClick: () => {
                handleClose();
                handleLogout();
              },
              children: [
                /* @__PURE__ */ jsx(ListItemIcon, { children: /* @__PURE__ */ jsx(Logout, { fontSize: "small" }) }),
                "Logout"
              ]
            }
          )
        ]
      }
    )
  ] });
};
function Backend({ children, title = null }) {
  const [theme, colorMode] = useMode();
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: title ?? "CMS" }),
    /* @__PURE__ */ jsx(ColorModeContext.Provider, { value: colorMode, children: /* @__PURE__ */ jsx(ThemeProvider, { theme, children: /* @__PURE__ */ jsxs(SnackbarProvider, { maxSnack: 5, children: [
      /* @__PURE__ */ jsx(CssBaseline, {}),
      /* @__PURE__ */ jsxs("div", { className: "app", children: [
        /* @__PURE__ */ jsx(Sidebar, {}),
        /* @__PURE__ */ jsxs("main", { className: "content", children: [
          /* @__PURE__ */ jsx(Topbar, {}),
          children
        ] })
      ] }),
      /* @__PURE__ */ jsx(Notification, {})
    ] }) }) })
  ] });
}
function Header({ title, subtitle }) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  return /* @__PURE__ */ jsxs(Box, { mb: "30px", children: [
    /* @__PURE__ */ jsx(
      Typography,
      {
        variant: "h2",
        color: colors.danamonAccent[100],
        fontWeight: "bold",
        sx: { m: "0 0 5px 0" },
        children: title
      }
    ),
    /* @__PURE__ */ jsx(Typography, { variant: "h5", color: colors.danamonAccent[400], children: subtitle })
  ] });
}
export {
  Backend as B,
  Header as H,
  createUrlImage as c,
  getUrlSearchParameter as g,
  hasAnyPermission as h
};
