import { jsxs, jsx, Fragment } from "react/jsx-runtime";
import { useState } from "react";
import { H as Header, g as getUrlSearchParameter, B as Backend } from "./Header-053b50f1.js";
import { Box, Button, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, Avatar, TablePagination } from "@mui/material";
import { router } from "@inertiajs/react";
import { C as ConfirmDeleteDialog } from "./ConfirmDeleteDialog-385a8cff.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
import "@mui/material/Button/index.js";
import "@mui/material/Dialog/index.js";
import "@mui/material/DialogActions/index.js";
import "@mui/material/DialogContent/index.js";
import "@mui/material/DialogContentText/index.js";
import "@mui/material/DialogTitle/index.js";
function Index({ users }) {
  const handleEdit = (id) => {
    router.get(route("cms.access.user.edit", { user: id }));
  };
  const [openConfirmDelete, setOpenConfirmDelete] = useState(false);
  const [routeDelete, setRouteDelete] = useState("");
  const handleDelete = (id) => {
    setOpenConfirmDelete(true);
    setRouteDelete(route("cms.access.user.delete", { user: id }));
  };
  const handleChangePage = (event, newPage) => {
    console.log(newPage);
    users.meta.current_page < newPage + 1 ? router.get(
      users.links.next,
      {
        ...getUrlSearchParameter("size") && {
          size: getUrlSearchParameter("size")
        }
      },
      { preserveScroll: true, preserveState: true }
    ) : router.get(
      users.links.prev,
      {
        ...getUrlSearchParameter("size") && {
          size: getUrlSearchParameter("size")
        }
      },
      { preserveScroll: true, preserveState: true }
    );
  };
  const handleChangeRowsPerPage = (event) => {
    router.get(
      route("cms.access.user.index"),
      { size: +event.target.value },
      { preserveScroll: true, preserveState: true }
    );
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `User Management`, subtitle: `Manage user` }),
    /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "start", mt: "20px", gap: "5px", children: /* @__PURE__ */ jsx(
      Button,
      {
        type: "submit",
        color: "secondary",
        variant: "contained",
        onClick: () => router.get(route("cms.access.user.create")),
        children: "Create User"
      }
    ) }),
    /* @__PURE__ */ jsx(TableContainer, { sx: { maxHeight: "70vh" }, children: /* @__PURE__ */ jsxs(Table, { stickyHeader: true, "aria-label": "sticky table", children: [
      /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: "Avatar" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Name" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Email" }),
        /* @__PURE__ */ jsx(TableCell, { children: "Username" }),
        /* @__PURE__ */ jsx(TableCell, { align: "center", children: "Role" }),
        /* @__PURE__ */ jsx(TableCell, { align: "right", children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: users.data.map((user, index) => /* @__PURE__ */ jsxs(
        TableRow,
        {
          sx: {
            "&:last-child td, &:last-child th": {
              border: 0
            }
          },
          children: [
            /* @__PURE__ */ jsx(TableCell, { children: /* @__PURE__ */ jsx(
              Avatar,
              {
                sx: {
                  width: 50,
                  height: 50,
                  cursor: "pointer"
                },
                src: user.avatar
              }
            ) }),
            /* @__PURE__ */ jsx(TableCell, { children: user.name }),
            /* @__PURE__ */ jsx(TableCell, { children: user.email }),
            /* @__PURE__ */ jsx(TableCell, { children: user.username }),
            /* @__PURE__ */ jsx(TableCell, { align: "center", children: user.role.map(
              (role) => /* @__PURE__ */ jsxs(Fragment, { children: [
                /* @__PURE__ */ jsx("span", { children: role }, role),
                /* @__PURE__ */ jsx("br", {})
              ] })
            ) }),
            /* @__PURE__ */ jsxs(TableCell, { align: "right", className: "!space-x-2", children: [
              /* @__PURE__ */ jsx(
                Button,
                {
                  color: "neutral",
                  variant: "contained",
                  onClick: () => handleEdit(user.username),
                  className: "mt-2",
                  children: "Edit"
                }
              ),
              /* @__PURE__ */ jsx(
                Button,
                {
                  color: "danger",
                  variant: "contained",
                  onClick: () => handleDelete(user.username),
                  className: "mt-2",
                  children: "Delete"
                }
              )
            ] })
          ]
        },
        `${user.name} ${index}`
      )) })
    ] }) }),
    /* @__PURE__ */ jsx(
      TablePagination,
      {
        rowsPerPageOptions: [5, 10, 20, 100],
        component: "div",
        count: users.meta.total,
        rowsPerPage: users.meta.per_page,
        page: users.meta.current_page - 1,
        onPageChange: handleChangePage,
        onRowsPerPageChange: handleChangeRowsPerPage
      }
    ),
    /* @__PURE__ */ jsx(
      ConfirmDeleteDialog,
      {
        openConfirmDelete,
        setOpenConfirmDelete,
        route: routeDelete
      }
    )
  ] });
}
Index.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "User Management" });
export {
  Index as default
};
