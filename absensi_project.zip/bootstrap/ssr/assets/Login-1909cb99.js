import { jsxs, jsx } from "react/jsx-runtime";
import { useTheme, FormControl, InputBase, FormHelperText, IconButton, Button } from "@mui/material";
import AlternateEmailIcon from "@mui/icons-material/AlternateEmail.js";
import VisibilityIcon from "@mui/icons-material/Visibility.js";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff.js";
import LoginIcon from "@mui/icons-material/Login.js";
import KeyIcon from "@mui/icons-material/Key.js";
import { useState, useCallback } from "react";
import { useForm, Link } from "@inertiajs/react";
import { A as Auth } from "./Auth-7c9e6626.js";
import { t as tokens } from "./Notification-dd8222ef.js";
import { GoogleReCaptcha } from "react-google-recaptcha-v3";
import "notistack";
import "@mui/material/styles/createTheme.js";
function Login({ nama }) {
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const { data, setData, errors, post, processing, reset } = useForm({});
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [refreshReCaptcha, setRefreshReCaptcha] = useState(false);
  const handleInput = (e) => {
    setData((prevData) => ({
      ...prevData,
      [e.target.name]: e.target.value
    }));
  };
  const handleSignIn = (e) => {
    e.preventDefault();
    post(route("web.login.process"), {
      onSuccess: (page) => {
        reset();
      },
      onError: (e2) => {
        setRefreshReCaptcha((r) => !r);
      }
    });
  };
  const onVerify = useCallback(
    (token) => {
      setData((prev) => ({ ...prev, "g-recaptcha-response": token }));
    },
    [refreshReCaptcha]
  );
  return /* @__PURE__ */ jsxs("div", { className: "h-screen lg:flex", children: [
    /* @__PURE__ */ jsx(
      "div",
      {
        className: `flex w-full lg:w-1/2 py-4 lg:py-0 justify-around items-center`,
        style: { backgroundColor: colors.danamonAccent[600] },
        children: /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx(
            Link,
            {
              className: "block w-72 aspect-[11/4] p-1 rounded-md",
              children: /* @__PURE__ */ jsx("img", { src: "/assets/images/concrete-logo.png", alt: "concrete logo", className: "object-contain w-full h-full" })
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col items-center mt-5 justify-center", children: [
            /* @__PURE__ */ jsx("p", { className: "text-2xl text-white", children: "CONCRETE CLOCK IN" }),
            /* @__PURE__ */ jsx("p", { className: "text-xl text-white", children: "USER" })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center w-full lg:w-1/2", children: /* @__PURE__ */ jsxs(
      "form",
      {
        onSubmit: handleSignIn,
        className: "w-full p-8 md:w-3/4 lg:w-1/2 lg:p-0 mt-44 lg:mt-0",
        children: [
          /* @__PURE__ */ jsx(
            GoogleReCaptcha,
            {
              onVerify,
              refreshReCaptcha
            }
          ),
          /* @__PURE__ */ jsx("h1", { className: "mb-1 text-xl font-bold", children: "Halo Selamat Datang Kembali!" }),
          /* @__PURE__ */ jsx("p", { className: "text-sm font-normal mb-7", children: "Silahkan Masukan Credential Anda" }),
          /* @__PURE__ */ jsxs(FormControl, { className: "w-full", sx: { mb: 1 }, children: [
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: `flex items-center border-2 py-2 px-3 rounded-2xl ${errors.email && "border-red-500 text-red-500"}`,
                children: [
                  /* @__PURE__ */ jsx(AlternateEmailIcon, { sx: { color: "inherit" } }),
                  /* @__PURE__ */ jsx(
                    InputBase,
                    {
                      type: "text",
                      sx: {
                        ml: 1,
                        color: "inherit",
                        flex: 1,
                        borderRadius: 2,
                        overflow: "hidden",
                        "& > input:-webkit-autofill": {
                          WebkitTextFillColor: colors.danamonAccent[300],
                          caretColor: colors.danamonAccent[300],
                          WebkitBoxShadow: `0 0 0px 1000px transparent inset`,
                          transition: "background-color 5000s ease-in-out 0s"
                        }
                      },
                      autoFocus: true,
                      placeholder: "Masukan email",
                      name: "email",
                      onChange: handleInput,
                      inputProps: {
                        "aria-label": "Masukan email anda"
                      }
                    }
                  )
                ]
              }
            ),
            errors.email && /* @__PURE__ */ jsx(FormHelperText, { error: true, children: errors.email })
          ] }),
          /* @__PURE__ */ jsxs(FormControl, { className: "w-full", sx: { mb: 1 }, children: [
            /* @__PURE__ */ jsxs(
              "div",
              {
                className: `flex items-center border-2 py-2 px-3 rounded-2xl ${errors.password && "border-red-500 text-red-500"}`,
                children: [
                  /* @__PURE__ */ jsx(KeyIcon, { sx: { color: "inherit" } }),
                  /* @__PURE__ */ jsx(
                    InputBase,
                    {
                      type: passwordVisible ? "text" : "password",
                      sx: {
                        ml: 1,
                        color: "inherit",
                        flex: 1,
                        borderRadius: 2,
                        overflow: "hidden",
                        "& > input:-webkit-autofill": {
                          WebkitTextFillColor: colors.danamonAccent[300],
                          caretColor: colors.danamonAccent[300],
                          WebkitBoxShadow: `0 0 0px 1000px transparent inset`,
                          transition: "background-color 5000s ease-in-out 0s"
                        }
                      },
                      placeholder: "Masukan password anda",
                      name: "password",
                      onChange: handleInput,
                      inputProps: {
                        "aria-label": "Masukan email anda"
                      }
                    }
                  ),
                  /* @__PURE__ */ jsx(
                    IconButton,
                    {
                      type: "button",
                      sx: { p: "4px", color: "inherit" },
                      "aria-label": "visibility password",
                      onClick: () => setPasswordVisible(!passwordVisible),
                      children: passwordVisible ? /* @__PURE__ */ jsx(
                        VisibilityOffIcon,
                        {
                          sx: { color: "inherit" }
                        }
                      ) : /* @__PURE__ */ jsx(VisibilityIcon, { sx: { color: "inherit" } })
                    }
                  )
                ]
              }
            ),
            errors.password && /* @__PURE__ */ jsx(FormHelperText, { error: true, children: errors.password })
          ] }),
          /* @__PURE__ */ jsxs(
            Button,
            {
              disabled: processing,
              type: "submit",
              variant: "contained",
              size: "medium",
              sx: {
                backgroundColor: colors.danamonAccent[600],
                "&:hover": {
                  backgroundColor: colors.danamonAccent[700]
                },
                "&:disabled": {
                  backgroundColor: colors.danamonAccent[800]
                }
              },
              className: "flex items-center justify-center w-full !mt-2 py-2 !rounded-2xl !font-semibold !mb-2",
              children: [
                "Sign In  ",
                /* @__PURE__ */ jsx("span", { children: processing ? /* @__PURE__ */ jsx(
                  "svg",
                  {
                    className: "h-5 w-5 m-[0.05rem]",
                    xmlns: "http://www.w3.org/2000/svg",
                    xmlnsXlink: "http://www.w3.org/1999/xlink",
                    viewBox: "0 0 100 100",
                    preserveAspectRatio: "xMidYMid",
                    children: /* @__PURE__ */ jsx(
                      "circle",
                      {
                        cx: 50,
                        cy: 50,
                        r: 46,
                        strokeWidth: 10,
                        stroke: "#fff",
                        strokeDasharray: "72.25663103256524 72.25663103256524",
                        fill: "none",
                        strokeLinecap: "round",
                        children: /* @__PURE__ */ jsx(
                          "animateTransform",
                          {
                            attributeName: "transform",
                            type: "rotate",
                            repeatCount: "indefinite",
                            dur: "0.7513513513513513s",
                            keyTimes: "0;1",
                            values: "0 50 50;360 50 50"
                          }
                        )
                      }
                    )
                  }
                ) : /* @__PURE__ */ jsx(LoginIcon, {}) })
              ]
            }
          )
        ]
      }
    ) })
  ] });
}
Login.layout = (page) => /* @__PURE__ */ jsx(Auth, { children: page, title: "Login CMS" });
export {
  Login as default
};
