import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, FormControl, InputLabel, Select, MenuItem, TextField, Button } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Edit({ attendance, users, categories, statuses }) {
  const isNonMobile = useMediaQuery("(min-width:600px)");
  const { data, setData, reset, errors, post } = useForm({
    user_id: attendance.data.user_id,
    clock_in: attendance.data.clock_in,
    clock_out: attendance.data.clock_out,
    clock_in_lat: attendance.data.clock_in_lat,
    clock_in_long: attendance.data.clock_in_long,
    category: attendance.data.category,
    status: attendance.data.status,
    _method: "put"
  });
  const handleChange = (e) => {
    let { name, value } = e.target;
    if (name === "clock_in" || name === "clock_out") {
      const date = new Date(value);
      value = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")} ${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}:00`;
    }
    setData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    post(route("cms.attendance.update", { attendance: attendance.data.slug }), {
      preserveScroll: true,
      preserveState: true,
      onSuccess: () => {
      }
    });
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Edit attendance", subtitle: "Edit New attendance Data" }),
    /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, children: [
      /* @__PURE__ */ jsxs(
        Box,
        {
          display: "grid",
          gap: "30px",
          gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
          sx: {
            "& > div": {
              gridColumn: isNonMobile ? void 0 : "span 4"
            }
          },
          children: [
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.user_id, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "user-label", children: "Select User" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "user-label",
                  id: "user_id",
                  value: data.user_id,
                  name: "user_id",
                  onChange: handleChange,
                  renderValue: (selected) => {
                    const selectedUser = users.find((user) => user.id === selected);
                    return selectedUser ? selectedUser.name : "Select User";
                  },
                  children: users && users.map((user) => /* @__PURE__ */ jsx(MenuItem, { value: user.id, children: user.name }, user.id))
                }
              ),
              !!errors.user_id && /* @__PURE__ */ jsx(FormHelperText, { error: !!errors.user_id, children: errors.user_id })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.category, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "marital-status-label", children: "Category" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "marital-status-label",
                  id: "category",
                  value: data.category,
                  name: "category",
                  onChange: handleChange,
                  renderValue: (selected) => selected || "Select Category",
                  children: Array.isArray(categories) && categories.map((category) => /* @__PURE__ */ jsx(MenuItem, { value: category, children: category }, category))
                }
              ),
              !!errors.category && /* @__PURE__ */ jsx(FormHelperText, { children: errors.category })
            ] }),
            /* @__PURE__ */ jsxs(FormControl, { variant: "filled", sx: { gridColumn: "span 4" }, error: !!errors.status, children: [
              /* @__PURE__ */ jsx(InputLabel, { id: "marital-status-label", children: "Status" }),
              /* @__PURE__ */ jsx(
                Select,
                {
                  labelId: "marital-status-label",
                  id: "status",
                  value: data.status,
                  name: "status",
                  onChange: handleChange,
                  renderValue: (selected) => selected || "Select status",
                  children: Array.isArray(statuses) && statuses.map((status) => /* @__PURE__ */ jsx(MenuItem, { value: status, children: status }, status))
                }
              ),
              !!errors.status && /* @__PURE__ */ jsx(FormHelperText, { children: errors.status })
            ] }),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "datetime-local",
                label: "Clock In",
                onChange: handleChange,
                name: "clock_in",
                value: data.clock_in ? data.clock_in.replace(" ", "T").slice(0, 16) : "",
                InputLabelProps: { shrink: true },
                error: !!errors.clock_in,
                helperText: errors.clock_in,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "datetime-local",
                label: "Clock Out",
                onChange: handleChange,
                name: "clock_out",
                value: data.clock_out ? data.clock_out.replace(" ", "T").slice(0, 16) : "",
                InputLabelProps: { shrink: true },
                error: !!errors.clock_out,
                helperText: errors.clock_out,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "clock_in_lat",
                onChange: handleChange,
                name: "clock_in_lat",
                value: data.clock_in_lat,
                error: !!errors.clock_in_lat,
                helperText: errors.clock_in_lat,
                sx: { gridColumn: "span 2" }
              }
            ),
            /* @__PURE__ */ jsx(
              TextField,
              {
                fullWidth: true,
                variant: "filled",
                type: "text",
                label: "clock_in_long",
                onChange: handleChange,
                name: "clock_in_long",
                value: data.clock_in_long,
                error: !!errors.clock_in_long,
                helperText: errors.clock_in_long,
                sx: { gridColumn: "span 2" }
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "end", mt: "20px", children: /* @__PURE__ */ jsx(Button, { type: "submit", color: "secondary", variant: "contained", children: "Submit" }) })
    ] })
  ] });
}
Edit.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Edit attendance" });
export {
  Edit as default
};
