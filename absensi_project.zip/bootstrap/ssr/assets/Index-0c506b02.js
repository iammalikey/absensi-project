import { jsxs, jsx } from "react/jsx-runtime";
import { useState } from "react";
import { H as Header, g as getUrlSearchParameter, B as Backend } from "./Header-053b50f1.js";
import { Box, Button, TableContainer, Table, TableHead, TableRow, TableCell, TableBody, TablePagination } from "@mui/material";
import { router } from "@inertiajs/react";
import { C as ConfirmDeleteDialog } from "./ConfirmDeleteDialog-385a8cff.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
import "@mui/material/Button/index.js";
import "@mui/material/Dialog/index.js";
import "@mui/material/DialogActions/index.js";
import "@mui/material/DialogContent/index.js";
import "@mui/material/DialogContentText/index.js";
import "@mui/material/DialogTitle/index.js";
function Index({ divisions }) {
  const handleEdit = (id) => {
    router.get(route("cms.division.edit", { division: id }));
  };
  const [openConfirmDelete, setOpenConfirmDelete] = useState(false);
  const [routeDelete, setRouteDelete] = useState("");
  const handleDelete = (id) => {
    setOpenConfirmDelete(true);
    setRouteDelete(route("cms.division.delete", { division: id }));
  };
  const handleChangePage = (event, newPage) => {
    divisions.meta.current_page < newPage + 1 ? router.get(
      divisions.links.next,
      {
        ...getUrlSearchParameter("size") && {
          size: getUrlSearchParameter("size")
        }
      },
      { preserveScroll: true, preserveState: true }
    ) : router.get(
      divisions.links.prev,
      {
        ...getUrlSearchParameter("size") && {
          size: getUrlSearchParameter("size")
        }
      },
      { preserveScroll: true, preserveState: true }
    );
  };
  const handleChangeRowsPerPage = (event) => {
    router.get(
      route("cms.division.index"),
      { size: +event.target.value },
      { preserveScroll: true, preserveState: true }
    );
  };
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: `Division Management`, subtitle: `Manage Division` }),
    /* @__PURE__ */ jsx(Box, { display: "flex", justifyContent: "start", mt: "20px", gap: "5px", children: /* @__PURE__ */ jsx(
      Button,
      {
        type: "submit",
        color: "secondary",
        variant: "contained",
        onClick: () => router.get(route("cms.division.create")),
        children: "Add New Division"
      }
    ) }),
    /* @__PURE__ */ jsx(TableContainer, { sx: { maxHeight: "70vh" }, children: /* @__PURE__ */ jsxs(Table, { stickyHeader: true, "aria-label": "sticky table", children: [
      /* @__PURE__ */ jsx(TableHead, { children: /* @__PURE__ */ jsxs(TableRow, { children: [
        /* @__PURE__ */ jsx(TableCell, { children: "Title" }),
        /* @__PURE__ */ jsx(TableCell, { align: "right", children: "Action" })
      ] }) }),
      /* @__PURE__ */ jsx(TableBody, { children: divisions.data.map((item, index) => /* @__PURE__ */ jsxs(
        TableRow,
        {
          sx: {
            "&:last-child td, &:last-child th": {
              border: 0
            }
          },
          children: [
            /* @__PURE__ */ jsx(TableCell, { children: item.title }),
            /* @__PURE__ */ jsxs(TableCell, { align: "right", className: "!space-x-2", children: [
              /* @__PURE__ */ jsx(Button, { onClick: () => handleEdit(item.slug), color: "neutral", variant: "contained", className: "mt-2", children: "Edit" }),
              /* @__PURE__ */ jsx(Button, { onClick: () => handleDelete(item.slug), color: "danger", variant: "contained", className: "mt-2", children: "Delete" })
            ] })
          ]
        },
        `${item.title} ${index}`
      )) })
    ] }) }),
    /* @__PURE__ */ jsx(
      TablePagination,
      {
        rowsPerPageOptions: [5, 10, 20, 100],
        component: "div",
        count: divisions.meta.total,
        rowsPerPage: divisions.meta.per_page,
        page: divisions.meta.current_page - 1,
        onPageChange: handleChangePage,
        onRowsPerPageChange: handleChangeRowsPerPage
      }
    ),
    /* @__PURE__ */ jsx(
      ConfirmDeleteDialog,
      {
        openConfirmDelete,
        setOpenConfirmDelete,
        route: routeDelete
      }
    )
  ] });
}
Index.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Division Management" });
export {
  Index as default
};
