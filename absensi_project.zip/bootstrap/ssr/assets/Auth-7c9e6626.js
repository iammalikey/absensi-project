import { jsxs, Fragment, jsx } from "react/jsx-runtime";
import "react";
import { Head } from "@inertiajs/react";
import { ThemeProvider, CssBaseline } from "@mui/material";
import { u as useMode, C as ColorModeContext, N as Notification } from "./Notification-dd8222ef.js";
import { GoogleReCaptchaProvider } from "react-google-recaptcha-v3";
import { SnackbarProvider } from "notistack";
function Auth({ children, title = null }) {
  const [theme, colorMode] = useMode();
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Head, { title: title ?? "CMS" }),
    /* @__PURE__ */ jsx(ColorModeContext.Provider, { value: colorMode, children: /* @__PURE__ */ jsx(ThemeProvider, { theme, children: /* @__PURE__ */ jsx(SnackbarProvider, { maxSnack: 5, children: /* @__PURE__ */ jsxs(
      GoogleReCaptchaProvider,
      {
        reCaptchaKey: {}.VITE_GOOGLE_RECAPTCHA_SITE_KEY,
        children: [
          /* @__PURE__ */ jsx(CssBaseline, {}),
          /* @__PURE__ */ jsx("div", { className: "app", children: /* @__PURE__ */ jsx("main", { className: "content", children }) }),
          /* @__PURE__ */ jsx(Notification, {})
        ]
      }
    ) }) }) })
  ] });
}
export {
  Auth as A
};
