import { jsxs, jsx } from "react/jsx-runtime";
import { useForm } from "@inertiajs/react";
import { useMediaQuery, Box, Avatar, Container, Divider, Typography } from "@mui/material";
import "react";
import { H as Header, B as Backend } from "./Header-053b50f1.js";
import "./Notification-dd8222ef.js";
import "@mui/material/styles/createTheme.js";
import "notistack";
import "react-pro-sidebar";
import "@mui/icons-material/HomeOutlined.js";
import "@mui/icons-material/MenuOutlined.js";
import "@mui/icons-material/ManageAccounts.js";
import "@mui/icons-material/HomeWorkOutlined.js";
import "@mui/icons-material/GroupOutlined.js";
import "@mui/icons-material/ManageHistoryOutlined.js";
import "@mui/icons-material/BarChartOutlined.js";
import "@mui/icons-material/Badge.js";
import "@mui/icons-material/EditOff.js";
import "@mui/material/InputBase/index.js";
import "@mui/icons-material/Search.js";
import "@mui/icons-material";
function Show({ employee }) {
  var _a, _b, _c;
  useMediaQuery("(min-width:600px)");
  const { data } = useForm({
    full_name: employee.data.full_name,
    phone: employee.data.phone,
    place_of_birth: employee.data.place_of_birth,
    date_of_birth: employee.data.date_of_birth,
    gender: employee.data.gender,
    marital_status: employee.data.marital_status,
    religion: employee.data.religion,
    blood_type: employee.data.blood_type,
    address: employee.data.address,
    postal_code: employee.data.postal_code,
    nik: employee.data.nik,
    npwp: employee.data.npwp,
    avatar: (_a = employee.data.user) == null ? void 0 : _a.avatar,
    email: (_b = employee.data.user) == null ? void 0 : _b.email,
    division: (_c = employee.data.division) == null ? void 0 : _c.title
  });
  return /* @__PURE__ */ jsxs(Box, { m: "20px", children: [
    /* @__PURE__ */ jsx(Header, { title: "Employee Detail", subtitle: `${data.full_name}'s Detail` }),
    /* @__PURE__ */ jsxs(Box, { display: "flex", alignItems: "center", gap: "50px", mb: "40px", children: [
      /* @__PURE__ */ jsx(
        Avatar,
        {
          sx: {
            width: 200,
            height: 200
          },
          src: data.avatar
        }
      ),
      /* @__PURE__ */ jsxs(Container, { maxWidth: "md", children: [
        /* @__PURE__ */ jsx(Divider, { textAlign: "left", children: "Personal Data" }),
        /* @__PURE__ */ jsxs(Box, { display: "grid", gridTemplateColumns: "100px auto", gap: "20px", mt: "20px", children: [
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Name" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.full_name
          ] }),
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Place of Birth" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.place_of_birth
          ] }),
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Date of Birth" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.date_of_birth
          ] }),
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Marital Status" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.marital_status
          ] }),
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Religion" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.religion
          ] }),
          /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Blood Type" }),
          /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
            ":    ",
            data.blood_type
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx(Divider, { textAlign: "left", children: "Identity & Address" }),
    /* @__PURE__ */ jsxs(Box, { display: "grid", gridTemplateColumns: "100px auto", gap: "20px", mt: "20px", children: [
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Division:" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.division
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Phone:" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.phone
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Email:" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.email
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Address :" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.address
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "Postal Code :" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.postal_code
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "NIK :" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.nik
      ] }),
      /* @__PURE__ */ jsx(Typography, { variant: "subtitle2", color: "textSecondary", children: "NPWP :" }),
      /* @__PURE__ */ jsxs(Typography, { variant: "body1", children: [
        ":    ",
        data.npwp
      ] })
    ] })
  ] });
}
Show.layout = (page) => /* @__PURE__ */ jsx(Backend, { children: page, title: "Show Employee" });
export {
  Show as default
};
