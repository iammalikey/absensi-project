<?php

namespace App\Helpers;

class AlertHelper {

  const ALERT_SUCCESS = 'success';
  const ALERT_ERROR = 'error';
  const ALERT_INFO = 'info';

}