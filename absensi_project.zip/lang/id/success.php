<?php

return [
    'change_password' => 'Password :user berhasil diubah! 🎉',
    'crud_create' => ':type berhasil dibuat! 🎉',
    'crud_update' => ':type berhasil diupdate! 🎉',
    'crud_delete' => ':type berhasil dihapus! 🎉',
    'crud_restore' => ':type berhasil dikembalikan! 🎉',
];