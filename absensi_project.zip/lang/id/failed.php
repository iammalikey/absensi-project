<?php

return [
    'prohibited' => [
        'crud_edit' => ':type tidak boleh diubah! ❌',
        'crud_update' => ':type tidak boleh diubah! ❌',
        'crud_delete' => ':type tidak boleh dihapus! ❌',
    ]
];