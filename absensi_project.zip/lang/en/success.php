<?php

return [
    'change_password' => 'Password :user updated successfully! 🎉',
    'crud_create' => ':type created successfully! 🎉',
    'crud_update' => ':type updated successfully! 🎉',
    'crud_delete' => ':type deleted successfully! 🎉',
    'crud_restore' => ':type restored successfully! 🎉',
];