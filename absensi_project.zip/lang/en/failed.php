<?php

return [
    'prohibited' => [
      'crud_edit' => ':type edit is prohibited! ❌',
      'crud_update' => ':type update is prohibited! ❌',
      'crud_delete' => ':type delete is prohibited! ❌',
    ]
];